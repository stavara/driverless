"""
CarMaker Desktop Dashboard
==========================
App de escritorio (PyQt5 + pyqtgraph) para telemetria en vivo, cronometraje
de vueltas/sectores, mapa del track y analisis, conectandose directo por
TCP a CarMaker (sin navegador, sin servidor WebSocket).

Correr:
    python app.py

Si "pycarmaker" no esta instalado o no se puede conectar a CarMaker, arranca
en MODO DEMO (datos sinteticos) para poder probar la interfaz igual.
"""
from __future__ import annotations

import csv
import json
import logging
import os
import sys
import time
from typing import Dict, List, Optional

from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from carmaker_core import TelemetryState, TRACKS, LapRecord
from carmaker_client import CarMakerClient, DemoDataSource

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("app")

STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cm_dashboard_state.json")
POLL_MS = 50  # 20 Hz, igual que el bridge original

# Paleta (mismos colores que el dashboard web, para que se sienta igual)
COL_BG = "#0b0d0c"
COL_PANEL = "#141815"
COL_LINE = "#232923"
COL_TEXT = "#e7ece7"
COL_DIM = "#7c8a7c"
COL_ACCENT = "#7CFF6B"
COL_ACCENT2 = "#FF6B4A"
COL_BLUE = "#4AA3FF"
COL_PURPLE = "#B98CFF"
COL_YELLOW = "#FFD24A"

# Canales disponibles para "En vivo" y "Analisis" (clave interna, etiqueta, unidad, color)
CHANNELS = [
    ("Car.v",              "Velocidad",      "m/s",   COL_ACCENT),
    ("Car.ax",              "Acel. long.",    "m/s²",  COL_BLUE),
    ("Car.ay",              "Acel. lateral",  "m/s²",  COL_YELLOW),
    ("Car.YawRate",         "Yaw rate",       "rad/s", COL_PURPLE),
    ("Car.SideSlipAngle",   "Slip angle",     "deg",   "#FF9F4A"),
    ("DM.Steer.Ang",        "Volante",        "deg",   COL_PURPLE),
    ("DM.Gas",              "Gas",            "",      COL_ACCENT),
    ("DM.Brake",            "Freno",          "",      COL_ACCENT2),
    ("nHitCones",           "Conos",          "",      COL_ACCENT2),
]
CHANNEL_BY_KEY = {k: (label, unit, color) for k, label, unit, color in CHANNELS}

MAX_SAMPLES = 20000  # buffer de Analisis (~15 min a 20Hz)


def fmt(x, d=2) -> str:
    if isinstance(x, (int, float)) and not (isinstance(x, float) and (x != x)):
        return f"{x:.{d}f}"
    return "–"


class History:
    """Buffer de telemetria para la pestaña Analisis (equivalente al
    `history` del dashboard web)."""

    def __init__(self):
        self.t: List[float] = []
        self.data: Dict[str, List[Optional[float]]] = {k: [] for k, _, _, _ in CHANNELS}

    def append(self, t: float, d: dict):
        self.t.append(t)
        for k in self.data:
            self.data[k].append(d.get(k))
        if len(self.t) > MAX_SAMPLES:
            self.t.pop(0)
            for k in self.data:
                self.data[k].pop(0)

    def clear(self):
        self.t.clear()
        for k in self.data:
            self.data[k].clear()


def kpi_card(title: str, unit: str = "") -> tuple:
    """Crea un 'card' de KPI y devuelve (widget, value_label)."""
    box = QtWidgets.QFrame()
    box.setStyleSheet(
        f"QFrame {{ background:{COL_PANEL}; border:1px solid {COL_LINE}; border-radius:6px; }}"
    )
    layout = QtWidgets.QVBoxLayout(box)
    layout.setContentsMargins(12, 10, 12, 10)
    layout.setSpacing(2)

    lbl_title = QtWidgets.QLabel(title.upper())
    lbl_title.setStyleSheet(f"color:{COL_DIM}; font-size:10px; letter-spacing:1px; border:none;")
    layout.addWidget(lbl_title)

    row = QtWidgets.QHBoxLayout()
    lbl_value = QtWidgets.QLabel("–")
    lbl_value.setStyleSheet(f"color:{COL_TEXT}; font-size:22px; font-weight:600; border:none;")
    row.addWidget(lbl_value)
    if unit:
        lbl_unit = QtWidgets.QLabel(unit)
        lbl_unit.setStyleSheet(f"color:{COL_DIM}; font-size:11px; border:none;")
        row.addWidget(lbl_unit, alignment=QtCore.Qt.AlignBottom)
    row.addStretch()
    layout.addLayout(row)

    return box, lbl_value


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CarMaker Live Telemetry — Dashboard")
        self.resize(1500, 950)
        self.setStyleSheet(f"QMainWindow {{ background:{COL_BG}; }} QWidget {{ color:{COL_TEXT}; }}")

        pg.setConfigOption("background", COL_PANEL)
        pg.setConfigOption("foreground", COL_DIM)

        self.state = TelemetryState(track_key="autox")
        self._load_persisted()

        self.history = History()
        self.client = None
        self.demo_mode = False
        self._connect_client()

        self._build_ui()
        self._render_track()
        self._render_lap_table()

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.timer.start(POLL_MS)

        self._autosave_timer = QtCore.QTimer(self)
        self._autosave_timer.timeout.connect(self._save_persisted)
        self._autosave_timer.start(2000)

    # ------------------------------------------------------------------
    # Conexion a CarMaker (con fallback a modo demo)
    # ------------------------------------------------------------------
    def _connect_client(self):
        try:
            client = CarMakerClient()
            client.connect()
            self.client = client
            self.demo_mode = False
            log.info("Conectado a CarMaker real.")
        except Exception as exc:
            log.warning("No se pudo conectar a CarMaker (%s). Arrancando en MODO DEMO.", exc)
            self.client = DemoDataSource()
            self.demo_mode = True

    # ------------------------------------------------------------------
    # Persistencia (solo vueltas ya cerradas, ver carmaker_core.py)
    # ------------------------------------------------------------------
    def _load_persisted(self):
        try:
            if os.path.exists(STATE_FILE):
                with open(STATE_FILE, "r", encoding="utf-8") as f:
                    self.state.load_persist_dict(json.load(f))
        except Exception as exc:
            log.warning("No se pudo cargar el estado guardado: %s", exc)

    def _save_persisted(self):
        try:
            with open(STATE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.state.to_persist_dict(), f)
        except Exception as exc:
            log.warning("No se pudo guardar el estado: %s", exc)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        outer = QtWidgets.QVBoxLayout(central)
        outer.setContentsMargins(16, 12, 16, 12)

        # -- Header --
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("CARMAKER  <span style='color:%s'>LIVE</span>  TELEMETRY" % COL_ACCENT)
        title.setStyleSheet(f"color:{COL_DIM}; font-size:15px; letter-spacing:2px; font-weight:600;")
        header.addWidget(title)
        header.addStretch()
        self.status_label = QtWidgets.QLabel("● conectando…")
        self.status_label.setStyleSheet(f"color:{COL_DIM}; font-family:monospace; padding:4px 10px; "
                                         f"border:1px solid {COL_LINE}; border-radius:3px;")
        header.addWidget(self.status_label)
        outer.addLayout(header)

        if self.demo_mode:
            demo_lbl = QtWidgets.QLabel("⚠ MODO DEMO — no se pudo conectar a CarMaker, mostrando datos sinteticos")
            demo_lbl.setStyleSheet(f"color:{COL_YELLOW}; font-family:monospace; padding:4px;")
            outer.addWidget(demo_lbl)

        # -- Tabs --
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setStyleSheet(f"""
            QTabWidget::pane {{ border: none; }}
            QTabBar::tab {{ background:{COL_PANEL}; color:{COL_DIM}; padding:8px 18px;
                            border:1px solid {COL_LINE}; border-radius:4px; margin-right:6px; }}
            QTabBar::tab:selected {{ color:{COL_ACCENT}; border-color:{COL_ACCENT}; }}
        """)
        outer.addWidget(self.tabs)
        self.tabs.currentChanged.connect(self._force_full_repaint)

        self._build_live_tab()
        self._build_laps_map_tab()
        self._build_analysis_tab()

    # -- Pestaña "En vivo" ------------------------------------------------
    def _build_live_tab(self):
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)

        kpis = QtWidgets.QHBoxLayout()
        self.kpi_labels = {}
        for key, title, unit in [
            ("speed", "Velocidad", "m/s"), ("steer", "Volante", "deg"),
            ("gas", "Gas", ""), ("brake", "Freno", ""),
            ("currentlap", "Vuelta actual", "s"), ("lastlap", "Última vuelta", "s"),
            ("bestlap", "Mejor vuelta", "s"), ("delta", "Delta vs. mejor", "s"),
        ]:
            box, lbl = kpi_card(title, unit)
            self.kpi_labels[key] = lbl
            kpis.addWidget(box)
        layout.addLayout(kpis)

        grid = QtWidgets.QGridLayout()
        self.live_plots = {}
        self.live_curves = {}
        self.live_buffers = {k: {"t": [], "v": []} for k, _, _, _ in CHANNELS}
        positions = [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2)]
        plot_channels = CHANNELS[:6]
        for (key, label, unit, color), pos in zip(plot_channels, positions):
            pw = pg.PlotWidget(title=f"{label} ({unit})" if unit else label)
            pw.showGrid(x=True, y=True, alpha=0.15)
            curve = pw.plot(pen=pg.mkPen(color=color, width=2))
            self.live_plots[key] = pw
            self.live_curves[key] = curve
            grid.addWidget(pw, pos[0], pos[1])
        layout.addLayout(grid)

        self.tabs.addTab(tab, "En vivo")

    # -- Pestaña "Vueltas y Mapa" (unificada) -----------------------------
    def _build_laps_map_tab(self):
        tab = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(tab)

        controls = QtWidgets.QHBoxLayout()
        controls.addWidget(QtWidgets.QLabel("Track:"))
        self.track_combo = QtWidgets.QComboBox()
        self.track_combo.addItem("Autocross (5 vueltas)", "autox")
        self.track_combo.addItem("Endurance (10 vueltas)", "endurance")
        idx = 0 if self.state.track_key == "autox" else 1
        self.track_combo.setCurrentIndex(idx)
        self.track_combo.currentIndexChanged.connect(self._on_track_changed)
        controls.addWidget(self.track_combo)

        controls.addSpacing(20)
        self.laps_status_label = QtWidgets.QLabel("")
        self.laps_status_label.setStyleSheet(f"color:{COL_DIM};")
        controls.addWidget(self.laps_status_label)
        controls.addStretch()

        btn_clear = QtWidgets.QPushButton("Borrar historial de vueltas")
        btn_clear.clicked.connect(self._on_clear_laps)
        controls.addWidget(btn_clear)

        btn_export = QtWidgets.QPushButton("Exportar CSV de vueltas")
        btn_export.clicked.connect(self._on_export_laps)
        controls.addWidget(btn_export)

        outer.addLayout(controls)

        # Mapa (izquierda) + tabla (derecha), uno al lado del otro
        split = QtWidgets.QHBoxLayout()

        self.map_plot = pg.PlotWidget()
        self.map_plot.setAspectLocked(True)
        self.map_plot.hideAxis("bottom")
        self.map_plot.hideAxis("left")
        self.map_plot.setMinimumWidth(480)
        split.addWidget(self.map_plot, 2)

        self.lap_table = QtWidgets.QTableWidget(0, 6)
        self.lap_table.setHorizontalHeaderLabels(["Vuelta", "Sector 1", "Sector 2", "Sector 3", "Total", "Conos"])
        self.lap_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.lap_table.setStyleSheet(f"QTableWidget {{ background:{COL_PANEL}; gridline-color:{COL_LINE}; }}")
        split.addWidget(self.lap_table, 3)

        outer.addLayout(split)
        self.tabs.addTab(tab, "Vueltas y Mapa")

    # -- Pestaña "Analisis" ------------------------------------------------
    def _build_analysis_tab(self):
        tab = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(tab)

        controls = QtWidgets.QHBoxLayout()
        controls.addWidget(QtWidgets.QLabel("Canales:"))
        self.channel_checks = {}
        default_selected = {"Car.v", "DM.Steer.Ang"}
        for key, label, unit, color in CHANNELS:
            cb = QtWidgets.QCheckBox(label)
            cb.setChecked(key in default_selected)
            cb.stateChanged.connect(self._rebuild_analysis_plots)
            self.channel_checks[key] = cb
            controls.addWidget(cb)
        controls.addStretch()

        self.live_pause_btn = QtWidgets.QPushButton("● EN VIVO")
        self.live_pause_btn.setCheckable(True)
        self.live_pause_btn.clicked.connect(self._toggle_live_pause)
        controls.addWidget(self.live_pause_btn)

        btn_export = QtWidgets.QPushButton("Exportar CSV")
        btn_export.clicked.connect(self._on_export_analysis)
        controls.addWidget(btn_export)

        btn_clear = QtWidgets.QPushButton("Limpiar historial")
        btn_clear.clicked.connect(self._on_clear_history)
        controls.addWidget(btn_clear)

        outer.addLayout(controls)

        range_row = QtWidgets.QHBoxLayout()
        range_row.addWidget(QtWidgets.QLabel("Ventana:"))
        self.range_group = QtWidgets.QButtonGroup(self)
        self.range_seconds = 60
        for label, secs in [("10s", 10), ("30s", 30), ("60s", 60), ("Todo", None)]:
            btn = QtWidgets.QPushButton(label)
            btn.setCheckable(True)
            btn.setChecked(secs == 60)
            btn.clicked.connect(lambda _, s=secs: self._set_range(s))
            self.range_group.addButton(btn)
            range_row.addWidget(btn)
        range_row.addStretch()
        outer.addLayout(range_row)

        self.analysis_plots_container = QtWidgets.QVBoxLayout()
        outer.addLayout(self.analysis_plots_container)
        self.analysis_plots = {}
        self._rebuild_analysis_plots()

        self.tabs.addTab(tab, "Análisis")

    # ------------------------------------------------------------------
    # Polling principal
    # ------------------------------------------------------------------
    def _poll(self):
        try:
            d = self.client.read_all()
        except Exception as exc:
            self.status_label.setText("● error leyendo CarMaker")
            log.warning("Error leyendo datos: %s", exc)
            return

        result = self.state.update(d)

        if result.full_reset:
            self.history.clear()
            self._clear_live_buffers()
            self._render_lap_table()
            self._save_persisted()

        if not result.armed:
            self.status_label.setText("● conectado — esperando que arranque la sim…")
            self.status_label.setStyleSheet(f"color:{COL_YELLOW}; font-family:monospace; padding:4px 10px; "
                                             f"border:1px solid {COL_LINE}; border-radius:3px;")
            self.kpi_labels["currentlap"].setText("–")
            return

        self.status_label.setText("● en vivo" if not self.demo_mode else "● en vivo (demo)")
        self.status_label.setStyleSheet(f"color:{COL_ACCENT}; font-family:monospace; padding:4px 10px; "
                                         f"border:1px solid {COL_LINE}; border-radius:3px;")

        t = result.t
        self.history.append(t, d)
        self._push_live_buffers(t, d)

        # KPIs
        self.kpi_labels["speed"].setText(fmt(d.get("Car.v")))
        self.kpi_labels["steer"].setText(fmt(d.get("DM.Steer.Ang")))
        self.kpi_labels["gas"].setText(fmt(d.get("DM.Gas")))
        self.kpi_labels["brake"].setText(fmt(d.get("DM.Brake")))
        self.kpi_labels["currentlap"].setText(fmt(result.current_lap_elapsed))

        if result.lap_completed is not None:
            self._on_lap_completed(result.lap_completed)

        self._update_car_dot(d.get("Car.tx"), d.get("Car.ty"))

        # refrescar solo la pestaña visible (mas fluido)
        current_tab = self.tabs.currentWidget()
        if current_tab is self.tabs.widget(0):
            self._refresh_live_plots()
        elif current_tab is self.tabs.widget(1):
            self._render_lap_table()  # refresca la fila "en curso" en vivo, no solo al cerrar vuelta
        elif current_tab is self.tabs.widget(2):
            self._refresh_analysis_plots()

    def _force_full_repaint(self):
        """Fuerza un repintado completo al cambiar de pestaña, para evitar
        restos visuales ('fantasmas') de la pestaña anterior en algunos
        entornos (escritorio remoto / VM)."""
        self.repaint()
        QtCore.QTimer.singleShot(0, self.update)

    def _clear_live_buffers(self):
        for k in self.live_buffers:
            self.live_buffers[k]["t"].clear()
            self.live_buffers[k]["v"].clear()

    def _push_live_buffers(self, t, d):
        for k in self.live_buffers:
            buf = self.live_buffers[k]
            buf["t"].append(t)
            buf["v"].append(d.get(k))
            if len(buf["t"]) > 400:
                buf["t"].pop(0)
                buf["v"].pop(0)

    def _refresh_live_plots(self):
        for key, curve in self.live_curves.items():
            buf = self.live_buffers[key]
            curve.setData(buf["t"], [v if isinstance(v, (int, float)) else float("nan") for v in buf["v"]])

    # ------------------------------------------------------------------
    # Vueltas / Mapa
    # ------------------------------------------------------------------
    def _on_track_changed(self, idx):
        self.state.track_key = self.track_combo.currentData()
        self._render_track()
        self._save_persisted()

    def _render_track(self):
        track = TRACKS.get(self.state.track_key)
        self.map_plot.clear()
        if not track:
            return
        xs = [p[0] for p in track["points"]]
        ys = [p[1] for p in track["points"]]
        self.map_plot.plot(xs, ys, pen=pg.mkPen(color="#3a423a", width=6))

        for i, m in enumerate(track["markers"]):
            color = COL_ACCENT if i == 0 else COL_YELLOW
            label = "META" if i == 0 else f"S{i+1}"
            scatter = pg.ScatterPlotItem([m["xy"][0]], [m["xy"][1]], brush=pg.mkBrush(color), size=14)
            self.map_plot.addItem(scatter)
            text = pg.TextItem(label, color=COL_TEXT, anchor=(0.5, 1.3))
            text.setPos(m["xy"][0], m["xy"][1])
            self.map_plot.addItem(text)

        self.car_trail_curve = self.map_plot.plot([], [], pen=pg.mkPen(color=COL_ACCENT2, width=2))
        self.car_dot = pg.ScatterPlotItem([], [], brush=pg.mkBrush("#FF3B3B"), size=14,
                                           pen=pg.mkPen("#ffffff", width=1))
        self.map_plot.addItem(self.car_dot)
        self._car_trail_xy: List[tuple] = []

    def _update_car_dot(self, x, y):
        if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
            return
        self._car_trail_xy.append((x, y))
        if len(self._car_trail_xy) > 400:
            self._car_trail_xy.pop(0)
        self.car_dot.setData([x], [y])
        self.car_trail_curve.setData([p[0] for p in self._car_trail_xy], [p[1] for p in self._car_trail_xy])

    def _on_lap_completed(self, rec: LapRecord):
        self._render_lap_table()
        self._save_persisted()

    def _render_lap_table(self):
        laps = self.state.lap_history
        self.lap_table.setRowCount(len(laps) + (1 if self.state.lap_start_t is not None else 0))

        best_idx = None
        if laps:
            best_idx = min(range(len(laps)), key=lambda i: laps[i].total)

        for i, lap in enumerate(laps):
            self._set_lap_row(i, lap.lap_no, lap.sectors, lap.total, lap.cones, best=(i == best_idx))

        if self.state.lap_start_t is not None:
            row = len(laps)
            live_total = (self.state.last_rel_t - self.state.lap_start_t) if self.state.last_rel_t is not None else 0
            self._set_lap_row(row, f"{self.state.lap_counter} (en curso)",
                               self.state.sectors_this_lap, live_total, self.state.prev_cones,
                               in_progress=True)

        if laps:
            best = laps[best_idx]
            self.laps_status_label.setText(f"{len(laps)} vuelta(s) · mejor: {best.total:.3f}s (vuelta {best.lap_no})")
        else:
            self.laps_status_label.setText("⏳ esperando vueltas…" if self.state.state == "waiting" else "Sin vueltas todavía.")

    def _set_lap_row(self, row, lap_label, sectors, total, cones, best=False, in_progress=False):
        def cell(text, color=None):
            item = QtWidgets.QTableWidgetItem(str(text))
            item.setTextAlignment(QtCore.Qt.AlignCenter)
            if color:
                item.setForeground(QtGui.QColor(color))
            return item

        color_row = COL_YELLOW if in_progress else None
        self.lap_table.setItem(row, 0, cell(lap_label, color_row))
        for i in range(3):
            v = sectors[i] if i < len(sectors) else None
            txt = f"{v:.3f}" if isinstance(v, (int, float)) else "–"
            self.lap_table.setItem(row, i + 1, cell(txt, color_row))
        self.lap_table.setItem(row, 4, cell(f"{total:.3f}" if isinstance(total, (int, float)) else "–",
                                             COL_ACCENT if best else color_row))
        self.lap_table.setItem(row, 5, cell(cones if cones is not None else "–",
                                             COL_ACCENT2 if (cones and cones > 0) else color_row))

    def _on_clear_laps(self):
        self.state.clear_laps()
        self._render_lap_table()
        self._save_persisted()

    def _on_export_laps(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Exportar vueltas", "vueltas.csv", "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["lapNo", "sector1", "sector2", "sector3", "total", "cones"])
            for lap in self.state.lap_history:
                s = lap.sectors + [None] * (3 - len(lap.sectors))
                writer.writerow([lap.lap_no, s[0], s[1], s[2], lap.total, lap.cones])
        QtWidgets.QMessageBox.information(self, "Listo", f"Vueltas exportadas a:\n{path}")

    # ------------------------------------------------------------------
    # Analisis
    # ------------------------------------------------------------------
    def _selected_channels(self):
        return [k for k, cb in self.channel_checks.items() if cb.isChecked()]

    def _set_range(self, secs):
        self.range_seconds = secs
        self.live_pause_btn.setChecked(False)
        self.live_pause_btn.setText("● EN VIVO")

    def _toggle_live_pause(self):
        paused = self.live_pause_btn.isChecked()
        self.live_pause_btn.setText("⏸ PAUSADO" if paused else "● EN VIVO")

    def _rebuild_analysis_plots(self):
        while self.analysis_plots_container.count():
            item = self.analysis_plots_container.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
        self.analysis_plots = {}

        for key in self._selected_channels():
            label, unit, color = CHANNEL_BY_KEY[key]
            pw = pg.PlotWidget(title=f"{label} ({unit})" if unit else label)
            pw.showGrid(x=True, y=True, alpha=0.15)
            curve = pw.plot(pen=pg.mkPen(color=color, width=2))
            self.analysis_plots[key] = curve
            self.analysis_plots_container.addWidget(pw)

        self._refresh_analysis_plots()

    def _refresh_analysis_plots(self):
        if not self.analysis_plots or not self.history.t:
            return
        if self.live_pause_btn.isChecked():
            return  # pausado: no tocar lo que se esta mirando

        n = len(self.history.t)
        if self.range_seconds is None:
            start = 0
        else:
            end_t = self.history.t[-1]
            start = 0
            for i, tt in enumerate(self.history.t):
                if tt >= end_t - self.range_seconds:
                    start = i
                    break

        t_slice = self.history.t[start:]
        for key, curve in self.analysis_plots.items():
            v_slice = self.history.data[key][start:]
            curve.setData(t_slice, [v if isinstance(v, (int, float)) else float("nan") for v in v_slice])

    def _on_export_analysis(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Exportar CSV", "telemetria.csv", "CSV (*.csv)")
        if not path:
            return
        keys = [k for k, _, _, _ in CHANNELS]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Time"] + keys)
            for i, t in enumerate(self.history.t):
                writer.writerow([t] + [self.history.data[k][i] for k in keys])
        QtWidgets.QMessageBox.information(self, "Listo", f"Telemetria exportada a:\n{path}")

    def _on_clear_history(self):
        self.history.clear()
        self._clear_live_buffers()
        self.state.clear_laps()
        self._render_lap_table()
        self._refresh_analysis_plots()
        self._save_persisted()

    # ------------------------------------------------------------------
    def closeEvent(self, event):
        self._save_persisted()
        if self.client:
            self.client.close()
        super().closeEvent(event)


GLOBAL_STYLESHEET = f"""
    QWidget {{
        background: {COL_BG};
        color: {COL_TEXT};
        font-family: "Consolas", "Courier New", monospace;
        font-size: 12px;
    }}
    QLabel {{ background: transparent; }}

    QPushButton {{
        background: {COL_PANEL};
        color: {COL_TEXT};
        border: 1px solid {COL_LINE};
        border-radius: 4px;
        padding: 6px 12px;
    }}
    QPushButton:hover {{ border-color: {COL_ACCENT}; color: {COL_ACCENT}; }}
    QPushButton:checked {{ color: {COL_ACCENT2}; border-color: {COL_ACCENT2}; }}
    QPushButton:pressed {{ background: {COL_LINE}; }}

    QComboBox {{
        background: {COL_PANEL};
        color: {COL_TEXT};
        border: 1px solid {COL_LINE};
        border-radius: 4px;
        padding: 4px 8px;
    }}
    QComboBox QAbstractItemView {{
        background: {COL_PANEL};
        color: {COL_TEXT};
        selection-background-color: {COL_LINE};
        selection-color: {COL_ACCENT};
        border: 1px solid {COL_LINE};
    }}

    QCheckBox {{ background: transparent; color: {COL_TEXT}; spacing: 6px; }}
    QCheckBox::indicator {{
        width: 14px; height: 14px;
        border: 1px solid {COL_LINE}; border-radius: 3px; background: {COL_PANEL};
    }}
    QCheckBox::indicator:checked {{ background: {COL_ACCENT}; border-color: {COL_ACCENT}; }}

    QTableWidget {{
        background: {COL_PANEL};
        color: {COL_TEXT};
        gridline-color: {COL_LINE};
        border: 1px solid {COL_LINE};
        selection-background-color: {COL_LINE};
        selection-color: {COL_ACCENT};
    }}
    QTableWidget::item {{ background: {COL_PANEL}; }}
    QHeaderView::section {{
        background: {COL_BG};
        color: {COL_DIM};
        border: 1px solid {COL_LINE};
        padding: 6px;
        font-weight: 600;
    }}
    QTableCornerButton::section {{ background: {COL_BG}; border: 1px solid {COL_LINE}; }}

    QScrollBar:vertical, QScrollBar:horizontal {{ background: {COL_PANEL}; border: none; }}
    QScrollBar::handle {{ background: {COL_LINE}; border-radius: 4px; }}
    QScrollBar::handle:hover {{ background: {COL_DIM}; }}

    QMessageBox, QFileDialog {{ background: {COL_BG}; color: {COL_TEXT}; }}
"""


def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(GLOBAL_STYLESHEET)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
