"""
Cliente de CarMaker: conexion TCP directa (misma API que usa IPGControl) y
lectura "segura" quantity por quantity, para que una variable mal escrita o
no disponible no tumbe la lectura del resto.

Tambien incluye un DemoDataSource, que genera datos sinteticos (sin
necesitar CarMaker corriendo) para poder probar la interfaz.
"""
from __future__ import annotations

import logging
import math
import random
import time
from typing import Dict, Any, List, Optional

log = logging.getLogger("carmaker_client")

QUANTITY_NAMES: List[str] = [
    "Time",
    "Car.v",
    "Car.ax",
    "Car.ay",
    "Car.Yaw",
    "Car.YawRate",
    "Car.SideSlipAngle",
    "Car.tx",
    "Car.ty",
    "DM.Steer.Ang",
    "DM.Gas",
    "DM.Brake",
    "current_sector",
    "current_sector_time",
    "lapTime",
    "nHitCones",
    "Vhcl.sRoad",
]


class CarMakerClient:
    """Wrapper sobre pycarmaker. Se importa pycarmaker recien al conectar,
    para que la app pueda arrancar en modo demo si no esta instalado."""

    def __init__(self, host: str = "localhost", port: int = 16660):
        self.host = host
        self.port = port
        self._cm = None
        self._quantities = []
        self._bad_quantities = set()

    def connect(self) -> None:
        from pycarmaker import CarMaker, Quantity  # import diferido

        self._cm = CarMaker(self.host, self.port)
        self._cm.connect()
        self._quantities = [Quantity(name, Quantity.FLOAT) for name in QUANTITY_NAMES]
        for q in self._quantities:
            self._cm.subscribe(q)
        log.info("Conectado a CarMaker y suscripto a %d quantities", len(self._quantities))

    def _read_quantity_safe(self, quantity) -> Optional[float]:
        try:
            self._cm.socket.send(quantity.read_msg.encode())
            raw = self._cm.socket.recv(300).decode()
            parts = raw.split("\r\n\r\n")
            if len(parts) != 2:
                raise ValueError(f"respuesta inesperada: {raw!r}")
            value_str = parts[0][1:]
            value = float(value_str) if type(quantity.type) == float else int(value_str)
            if quantity.name in self._bad_quantities:
                self._bad_quantities.discard(quantity.name)
                log.info("'%s' ahora responde OK", quantity.name)
            return value
        except Exception as exc:  # noqa: BLE001
            if quantity.name not in self._bad_quantities:
                self._bad_quantities.add(quantity.name)
                log.warning("Quantity '%s' invalida o sin datos: %s", quantity.name, exc)
            return None

    def read_all(self) -> Dict[str, Any]:
        return {q.name: self._read_quantity_safe(q) for q in self._quantities}

    def close(self) -> None:
        try:
            if self._cm is not None:
                self._cm.socket.close()
        except Exception:
            pass


class DemoDataSource:
    """Genera datos sinteticos de una vuelta al autox, en loop, para poder
    probar/desarrollar la interfaz sin CarMaker corriendo. Simula tambien
    un arranque "congelado" al principio y respeta el largo real del track
    (autox, 962.93 m) para que el cronometraje de sectores funcione igual
    que con datos reales."""

    def __init__(self, track_len: float = 962.934795673616, avg_speed: float = 18.0):
        self._t0 = time.time()
        self._frozen_seconds = 3.0   # simula el "leftover" antes de que le den a Run
        self._track_len = track_len
        self._avg_speed = avg_speed
        self._cones = 0
        self._paused_until: Optional[float] = None

    def toggle_pause(self, seconds: float = 4.0) -> None:
        """Simula apretar Stop: congela el reloj un rato."""
        self._paused_until = time.time() + seconds

    def read_all(self) -> Dict[str, Any]:
        now = time.time()
        elapsed = now - self._t0

        if self._paused_until is not None:
            if now < self._paused_until:
                elapsed = self._paused_until - self._t0  # tiempo congelado
            else:
                self._t0 += (now - (self._paused_until))  # corre el reloj para simular que sigue
                self._paused_until = None

        if elapsed < self._frozen_seconds:
            sim_t = 0.0  # "congelado" antes de arrancar
        else:
            sim_t = elapsed - self._frozen_seconds

        speed = self._avg_speed + 5 * math.sin(sim_t * 0.3)
        s_road = (sim_t * self._avg_speed) % self._track_len
        steer = 10 * math.sin(sim_t * 0.5)

        return {
            "Time": sim_t,
            "Car.v": max(speed, 0),
            "Car.ax": math.sin(sim_t * 0.4) * 3,
            "Car.ay": math.cos(sim_t * 0.4) * 4,
            "Car.Yaw": 0.0,
            "Car.YawRate": math.sin(sim_t * 0.4) * 0.3,
            "Car.SideSlipAngle": math.sin(sim_t) * 0.5,
            "Car.tx": s_road,  # posicion ficticia (no es el mapa real, solo para demo)
            "Car.ty": math.sin(s_road / 50) * 20,
            "DM.Steer.Ang": steer,
            "DM.Gas": max(0.0, math.sin(sim_t * 0.3)),
            "DM.Brake": max(0.0, -math.sin(sim_t * 0.3)),
            "current_sector": None,   # a proposito None: probar el respaldo por Vhcl.sRoad
            "current_sector_time": None,
            "lapTime": None,
            "nHitCones": self._cones,
            "Vhcl.sRoad": s_road,
        }

    def close(self) -> None:
        pass
