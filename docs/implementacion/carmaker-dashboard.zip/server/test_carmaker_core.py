"""
Pruebas con datos sinteticos para TelemetryState, sin Qt ni CarMaker real.
Corre con: python3 test_carmaker_core.py
"""
from carmaker_core import TelemetryState, compute_sector_from_sroad, TRACKS


def make_reading(t, sroad=None, sector=None, cones=0, v=10.0):
    d = {"Time": t, "Car.v": v, "nHitCones": cones}
    if sector is not None:
        d["current_sector"] = sector
    if sroad is not None:
        d["Vhcl.sRoad"] = sroad
    return d


def test_tracks_loaded():
    assert "autox" in TRACKS and "endurance" in TRACKS
    assert TRACKS["autox"]["len"] > 900
    print("OK: tracks cargados ->", {k: v["len"] for k, v in TRACKS.items()})


def test_sector_from_sroad():
    # limites conocidos del autox: 0, 215.59, 689.67, largo 962.93
    assert compute_sector_from_sroad(0, "autox") == 0
    assert compute_sector_from_sroad(100, "autox") == 0
    assert compute_sector_from_sroad(216, "autox") == 1
    assert compute_sector_from_sroad(700, "autox") == 2
    assert compute_sector_from_sroad(962.93 + 50, "autox") == 0  # wrap a la vuelta siguiente
    print("OK: compute_sector_from_sroad")


def test_waiting_until_time_advances():
    """Antes de arrancar, CarMaker manda Time congelado (ej 45.2 leftover).
    No debe armar ni grabar nada hasta que Time avance de verdad."""
    ts = TelemetryState("autox")
    for _ in range(10):
        r = ts.update(make_reading(45.2))
        assert r.armed is False
        assert r.waiting is True

    # ahora arranca de verdad: Time empieza a subir desde 0
    r = ts.update(make_reading(0.00))
    # el primer valor "distinto" recien arma en la SIGUIENTE lectura (necesita
    # 2 muestras para detectar que avanza)
    assert r.armed is False
    r = ts.update(make_reading(0.05))
    assert r.armed is True
    assert abs(r.t - 0.0) < 1e-9  # el offset se fijo en esta primera lectura real
    print("OK: no arranca hasta que Time avanza de verdad")


def test_full_lap_with_sector_fallback():
    """Simula una vuelta completa del autox usando SOLO Vhcl.sRoad (sin
    current_sector), y confirma que se detectan los 3 sectores y se cierra
    la vuelta con el tiempo correcto."""
    ts = TelemetryState("autox")
    length = TRACKS["autox"]["len"]

    t = 0.0
    dt = 0.05
    speed = 40.0  # m/s ficticio, rapido para no hacer el test eterno

    # arrancar (2 lecturas para armar)
    ts.update(make_reading(1000.0))  # valor congelado inicial (leftover)
    ts.update(make_reading(1000.0))
    ts.update(make_reading(1000.0 + dt))  # arranca aca (offset = 1000.0+dt)

    s_road = 0.0
    last_result = None
    for _ in range(int((length / speed) / dt) + 20):
        t += dt
        s_road += speed * dt
        r = ts.update(make_reading(1000.0 + dt + t, sroad=s_road))
        assert r.armed is True
        last_result = r
        if r.lap_completed is not None:
            break

    assert last_result.lap_completed is not None, "no se completo ninguna vuelta"
    lap = last_result.lap_completed
    assert lap.lap_no == 0
    assert len(lap.sectors) == 3, f"se esperaban 3 sectores, hay {len(lap.sectors)}"
    expected_total = length / speed
    assert abs(lap.total - expected_total) < 0.5, f"total {lap.total} vs esperado ~{expected_total}"
    print(f"OK: vuelta completa detectada -> total={lap.total:.2f}s sectores={[round(s,2) for s in lap.sectors]}")


def test_pause_then_resume_keeps_lap_history():
    """Simula: 1 vuelta completa, despues Stop (Time se congela), despues
    Play de nuevo (Time sigue avanzando desde donde quedo, SIN retroceder).
    Se espera: el dashboard pasa a 'esperando', y al resumir NO borra la
    vuelta ya completada, pero el tiempo relativo vuelve a arrancar en 0."""
    ts = TelemetryState("autox")
    length = TRACKS["autox"]["len"]
    speed = 50.0
    dt = 0.05

    ts.update(make_reading(500.0))
    ts.update(make_reading(500.0))
    ts.update(make_reading(500.0 + dt))

    t = 500.0 + dt
    s_road = 0.0
    completed = False
    while not completed:
        t += dt
        s_road += speed * dt
        r = ts.update(make_reading(t, sroad=s_road))
        if r.lap_completed is not None:
            completed = True

    assert len(ts.lap_history) == 1, "deberia haber exactamente 1 vuelta completada"

    # ---- STOP: Time se congela (varias lecturas seguidas con el mismo valor) ----
    frozen_t = t
    results = [ts.update(make_reading(frozen_t, sroad=s_road)) for _ in range(5)]
    # en algun punto de estas 5 lecturas tuvo que confirmar la pausa
    assert any(r.armed is False and r.waiting for r in results), "nunca detecto la pausa/stop"
    assert results[-1].armed is False and results[-1].waiting, "deberia seguir esperando"
    assert len(ts.lap_history) == 1, "NO debe perder la vuelta ya completada al pausar"

    # ---- PLAY de nuevo: Time sigue avanzando (no retrocede) ----
    r2 = ts.update(make_reading(frozen_t + dt, sroad=s_road))
    assert r2.armed is True, "deberia rearmar apenas Time vuelve a avanzar"
    assert abs(r2.t) < 1e-6, "el tiempo relativo tiene que volver a arrancar en 0 tras el resume"
    assert len(ts.lap_history) == 1, "la vuelta completada antes del stop se preserva"
    print("OK: pausa/stop conserva vueltas completadas y reinicia el tiempo relativo en 0")


def test_new_run_backward_jump_clears_everything():
    """Simula una vuelta completa y despues un salto de Time hacia atras
    grande (nueva corrida de CarMaker desde Test Manager) -> debe borrar
    TODO el historial de vueltas."""
    ts = TelemetryState("autox")
    length = TRACKS["autox"]["len"]
    speed = 60.0
    dt = 0.05

    ts.update(make_reading(10.0))
    ts.update(make_reading(10.0))
    ts.update(make_reading(10.0 + dt))

    t = 10.0 + dt
    s_road = 0.0
    completed = False
    while not completed:
        t += dt
        s_road += speed * dt
        r = ts.update(make_reading(t, sroad=s_road))
        if r.lap_completed is not None:
            completed = True

    assert len(ts.lap_history) == 1

    # salto grande hacia atras: nueva corrida arrancando en Time=0
    r = ts.update(make_reading(0.0, sroad=0.0))
    assert r.full_reset is True
    assert len(ts.lap_history) == 0, "una corrida nueva de verdad debe limpiar el historial"
    print("OK: salto de tiempo hacia atras limpia todo el historial (corrida nueva)")


def test_persist_roundtrip():
    ts = TelemetryState("autox")
    ts.lap_history = [__import__("carmaker_core").LapRecord(0, 45.1, [15.0, 15.0, 15.1], 0)]
    ts.lap_counter = 1
    ts.best_lap = 45.1
    ts.last_seen_lap_time = 45.1

    d = ts.to_persist_dict()
    js = __import__("json").dumps(d)  # confirma que es serializable
    d2 = __import__("json").loads(js)

    ts2 = TelemetryState("endurance")
    ts2.load_persist_dict(d2)
    assert ts2.track_key == "autox"
    assert ts2.lap_counter == 1
    assert len(ts2.lap_history) == 1
    assert ts2.lap_history[0].total == 45.1
    print("OK: persistencia (guardar/cargar) funciona")


if __name__ == "__main__":
    test_tracks_loaded()
    test_sector_from_sroad()
    test_waiting_until_time_advances()
    test_full_lap_with_sector_fallback()
    test_pause_then_resume_keeps_lap_history()
    test_new_run_backward_jump_clears_everything()
    test_persist_roundtrip()
    print("\nTODOS LOS TESTS PASARON")
