"""
Logica pura de telemetria y cronometraje para el dashboard de CarMaker.

Sin dependencias de Qt ni de pycarmaker a proposito: se alimenta con simples
diccionarios de quantities (como los que devuelve CarMakerClient) y devuelve
resultados simples. Esto permite testearla con datos sinteticos sin
necesitar Qt ni una conexion real a CarMaker corriendo.

Maquina de estados:

    WAITING  --(Time avanza)-->  RUNNING
    RUNNING  --(Time deja de avanzar N lecturas seguidas, ej. Stop/Pause)-->  WAITING

Ademas, si en cualquier momento "Time" retrocede de golpe (mas de
NEW_RUN_BACK_JUMP segundos), se interpreta como una corrida nueva de
CarMaker y se resetea TODO (incluidas las vueltas ya completadas).

Si en cambio se detecta una pausa/stop normal (Time se congela sin
retroceder), se vuelve a WAITING pero se conservan las vueltas ya
completadas -- solo se descarta la vuelta/sector que estaba en curso y se
recalcula un "cero" de tiempo relativo nuevo para la proxima vez que
arranque, tal como pidio el usuario ("que diga que esta esperando a
iniciar, igual que la primera vez").
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import json
import math
import os


# ---------------------------------------------------------------------------
# Datos de las pistas (extraidos de los .rd5 del challenge vFSAA): trazado
# completo (para dibujar el mapa) + limites de sector (distancia de ruta
# donde estan los 3 DrivManTrigger) + largo total de la vuelta.
# ---------------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))


def _load_track(filename: str) -> Dict[str, Any]:
    path = os.path.join(_HERE, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_tracks() -> Dict[str, Dict[str, Any]]:
    tracks = {}
    for key, filename in (
        ("autox", "track_autox_slim.json"),
        ("endurance", "track_endurance_slim.json"),
    ):
        try:
            tracks[key] = _load_track(filename)
        except FileNotFoundError:
            pass
    return tracks


TRACKS: Dict[str, Dict[str, Any]] = load_tracks()


def compute_sector_from_sroad(s_road: Optional[float], track_key: str) -> Optional[int]:
    """Respaldo para calcular el sector (0,1,2) usando Vhcl.sRoad + los
    limites de sector conocidos del track, sin depender de que CarMaker
    mande bien la quantity custom 'current_sector'."""
    track = TRACKS.get(track_key)
    if track is None or s_road is None:
        return None
    try:
        s_road = float(s_road)
    except (TypeError, ValueError):
        return None
    length = track.get("len") or 1.0
    s = s_road % length
    bounds = sorted(m["s"] for m in track["markers"])
    idx = 0
    for i, b in enumerate(bounds):
        if s >= b:
            idx = i
    return idx


PAUSE_CONFIRM_READS = 3    # lecturas seguidas sin avanzar para confirmar pausa/stop real
NEW_RUN_BACK_JUMP = 1.0    # segundos hacia atras para considerar "corrida nueva" de CarMaker


@dataclass
class LapRecord:
    lap_no: int
    total: float
    sectors: List[float]
    cones: Optional[float]

    def to_dict(self) -> dict:
        return {"lap_no": self.lap_no, "total": self.total, "sectors": self.sectors, "cones": self.cones}

    @staticmethod
    def from_dict(d: dict) -> "LapRecord":
        return LapRecord(d["lap_no"], d["total"], list(d.get("sectors", [])), d.get("cones"))


@dataclass
class TickResult:
    """Lo que la UI necesita en cada ciclo de lectura."""
    armed: bool
    waiting: bool = False                  # True mientras esta "esperando a iniciar" (primera vez o tras un stop/pausa)
    t: Optional[float] = None              # tiempo relativo (arranca en 0 cada vez que arma)
    current_lap_elapsed: Optional[float] = None
    lap_completed: Optional[LapRecord] = None
    sectors_in_progress: List[float] = field(default_factory=list)
    full_reset: bool = False               # True el ciclo en que se detecto una corrida nueva


class TelemetryState:
    def __init__(self, track_key: str = "autox"):
        self.track_key = track_key

        # maquina de estados
        self.state = "waiting"           # "waiting" | "running"
        self.t0_offset: Optional[float] = None
        self.prev_raw_t: Optional[float] = None
        self.stall_count = 0
        self.last_raw_t: Optional[float] = None

        # cronometraje de vuelta/sector en curso (en tiempo RELATIVO)
        self.lap_start_t: Optional[float] = None
        self.sector_start_t: Optional[float] = None
        self.last_sector: Optional[int] = None
        self.sectors_this_lap: List[float] = []
        self.prev_cones: Optional[float] = None

        # resultados acumulados
        self.lap_counter = 0
        self.lap_history: List[LapRecord] = []
        self.best_lap: Optional[float] = None
        self.last_seen_lap_time: Optional[float] = None

        self.last_rel_t: Optional[float] = None

    # -- persistencia (solo resultados, NO el cronometraje en curso) ------
    def to_persist_dict(self) -> dict:
        return {
            "track_key": self.track_key,
            "lap_counter": self.lap_counter,
            "lap_history": [l.to_dict() for l in self.lap_history],
            "best_lap": self.best_lap,
            "last_seen_lap_time": self.last_seen_lap_time,
        }

    def load_persist_dict(self, d: dict) -> None:
        self.track_key = d.get("track_key", self.track_key)
        self.lap_counter = d.get("lap_counter", 0)
        self.lap_history = [LapRecord.from_dict(x) for x in d.get("lap_history", [])]
        self.best_lap = d.get("best_lap")
        self.last_seen_lap_time = d.get("last_seen_lap_time")

    # -- reseteos ----------------------------------------------------------
    def _reset_in_progress(self) -> None:
        self.lap_start_t = None
        self.sector_start_t = None
        self.last_sector = None
        self.sectors_this_lap = []
        self.prev_cones = None

    def _reset_full(self) -> None:
        self._reset_in_progress()
        self.lap_counter = 0
        self.lap_history = []
        self.best_lap = None
        self.last_seen_lap_time = None

    def _rearm(self) -> None:
        """Vuelve a 'esperando arranque'. Se usa tanto en pausa/stop como
        en corrida nueva. NO borra lap_history (eso lo decide el llamador
        segun corresponda: pausa = conservar, corrida nueva = _reset_full)."""
        self.state = "waiting"
        self.prev_raw_t = None
        self.stall_count = 0
        self.t0_offset = None
        self._reset_in_progress()

    def clear_laps(self) -> None:
        """Para el boton 'Borrar' manual de la UI."""
        self._reset_full()

    # -- update principal ----------------------------------------------------
    def update(self, d: Dict[str, Any]) -> TickResult:
        raw_t = d.get("Time")
        try:
            raw_t = float(raw_t) if raw_t is not None else 0.0
        except (TypeError, ValueError):
            raw_t = 0.0

        full_reset = False
        # 1) corrida nueva de CarMaker: Time salto para atras de golpe
        if self.last_raw_t is not None and (raw_t < self.last_raw_t - NEW_RUN_BACK_JUMP):
            self._reset_full()
            self._rearm()
            full_reset = True
        self.last_raw_t = raw_t

        # 2) maquina de estados waiting/running
        if self.state == "waiting":
            advancing = (self.prev_raw_t is not None and raw_t > self.prev_raw_t)
            self.prev_raw_t = raw_t
            if not advancing:
                return TickResult(armed=False, waiting=True, full_reset=full_reset)
            self.state = "running"
            self.stall_count = 0
            if self.t0_offset is None:
                self.t0_offset = raw_t
        else:  # running
            advancing = (self.prev_raw_t is not None and raw_t > self.prev_raw_t)
            if advancing:
                self.stall_count = 0
                self.prev_raw_t = raw_t
            else:
                self.stall_count += 1
                self.prev_raw_t = raw_t
                if self.stall_count >= PAUSE_CONFIRM_READS:
                    self._rearm()
                    return TickResult(armed=False, waiting=True, full_reset=full_reset)

        # 3) tiempo relativo (arranca en 0 cada vez que se arma de nuevo)
        t = raw_t - self.t0_offset
        self.last_rel_t = t

        # 4) sector: current_sector si CarMaker lo manda bien, si no Vhcl.sRoad
        sector = d.get("current_sector")
        if not isinstance(sector, (int, float)) or (isinstance(sector, float) and math.isnan(sector)):
            s_road = d.get("Vhcl.sRoad")
            sector = compute_sector_from_sroad(s_road, self.track_key)

        lap_completed = None
        if sector is not None:
            sector = int(sector)
            if self.last_sector is None:
                self.sector_start_t = t
            elif sector != self.last_sector:
                sector_duration = (t - self.sector_start_t) if self.sector_start_t is not None else float("nan")
                self.sectors_this_lap.append(sector_duration)
                self.sector_start_t = t

                if sector < self.last_sector:
                    if self.lap_start_t is not None:
                        local_lap_time = t - self.lap_start_t
                        rec = LapRecord(self.lap_counter, local_lap_time, list(self.sectors_this_lap), self.prev_cones)
                        self.lap_history.append(rec)
                        self.lap_counter += 1
                        self.last_seen_lap_time = local_lap_time
                        self.best_lap = local_lap_time if self.best_lap is None else min(self.best_lap, local_lap_time)
                        lap_completed = rec
                    self.lap_start_t = t
                    self.sectors_this_lap = []
            self.last_sector = sector

        cones = d.get("nHitCones")
        if isinstance(cones, (int, float)):
            self.prev_cones = cones

        if self.lap_start_t is None:
            self.lap_start_t = t
        current_lap_elapsed = t - self.lap_start_t

        return TickResult(
            armed=True,
            t=t,
            current_lap_elapsed=current_lap_elapsed,
            lap_completed=lap_completed,
            sectors_in_progress=list(self.sectors_this_lap),
            full_reset=full_reset,
        )
