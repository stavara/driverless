@echo off
setlocal

:: =====================================================================
:: Lanzador de la app de escritorio CarMaker Dashboard
:: - Verifica/instala las dependencias de Python (PyQt5, pyqtgraph,
::   pycarmaker) la primera vez
:: - Corre app.py directamente (sin navegador, sin servidor)
::
:: Este .bat, app.py, carmaker_core.py, carmaker_client.py, y los 2
:: archivos track_*_slim.json deben estar TODOS en la misma carpeta.
:: =====================================================================

title CarMaker Dashboard
cd /d "%~dp0"

echo ============================================================
echo   CarMaker Desktop Dashboard
echo ============================================================
echo Carpeta de trabajo: %cd%
echo.

if not exist "app.py" (
    echo [ERROR] No encuentro "app.py" en esta carpeta.
    pause
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] No encuentro "python" en el PATH de Windows.
    echo         Instala Python 3.9+ y volve a correr este .bat.
    pause
    exit /b 1
)

echo Chequeando dependencias de Python (PyQt5, pyqtgraph)...
python -c "import PyQt5, pyqtgraph" 2>nul
if errorlevel 1 (
    echo Instalando dependencias, puede tardar un minuto la primera vez...
    python -m pip install --upgrade pip >nul
    python -m pip install PyQt5 pyqtgraph
)

python -c "import pycarmaker" 2>nul
if errorlevel 1 (
    echo Instalando pycarmaker...
    python -m pip install git+https://github.com/gmnvh/pycarmaker.git
)

echo.
echo Antes de continuar, asegurate de que CarMaker ya este abierto
echo (el TestRun puede estar corriendo o parado, no importa: la app
echo va a esperar sola a que le des a Run).
echo.
pause

python app.py

echo.
echo La app se cerro. Presiona una tecla para salir de esta ventana.
pause
